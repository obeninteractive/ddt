var request=new ajaxRequest();
var formshow=new Vue(
{    
	el:"#vueshowforms",
	data:{
		autoname:"",
		mainblock:true,err:"",
		mailengine:false,mailengine_apiurl:"",mailengine_apikey:"",mailengine_listid:"",mailengine_title:"",mailengine_email:"",
		activecampaign:false,active_apiurl:"",active_apikey:"",active_listid:"",active_title:"",
		mailchimp:false,mail_apikey:"",mail_listid:"",mail_email:"",mail_title:"",
		getresponse:false,get_apikey:"",get_campaignid:"",get_email:"",get_title:"",
		constantcont:false,const_apikey:"",const_token:"",const_listid:"",const_email:"",const_title:"",
		ontraport:false,ontra_apikey:"",ontra_appid:"",ontra_email:"",ontra_title:"",
		hubspot:false,hub_apikey:"",hub_email:"",hub_title:"",
		aweber:false,cus_key:"",cus_secret:"",acc_id:"",cus_email:"",list_id:"",cus_title:"",
		autoid:"",
	},
	 mounted:function(){
	 	document.onreadystatechange = () => { 
    if (document.readyState == "complete") {
		document.getElementById("editorformcontainer").style.display="block";
        // alert(this.autoname);
        this.editform();
    }
}
  },
	methods:{
	editform:function(){
		// alert(this.autoname);
		if(document.getElementById('autoname') && document.getElementById('autoname').value){
		this.autoname = document.getElementById('autoname').value;
		if (this.autoname == "mailengine") {
			this.autoid = document.getElementById('autoid').value;
			this.mailengine_title = document.getElementById('edittitle').value;
			this.mailengine_apikey = document.getElementById('editapikey').value;
			this.mailengine_apiurl = document.getElementById('editapiurl').value;
			this.mailengine_listid = document.getElementById('editlistid').value;
			this.mailengine=true;
			}
		if (this.autoname == "activecampaign") {
		this.autoid = document.getElementById('autoid').value;
		this.active_title = document.getElementById('edittitle').value;
		this.active_apikey = document.getElementById('editapikey').value;
        this.active_apiurl = document.getElementById('editapiurl').value;
        this.active_listid = document.getElementById('editlistid').value;
		this.activecampaign=true;
		}
		else if(this.autoname == "constantcont"){
		this.autoid = document.getElementById('autoid').value;
		this.const_title = document.getElementById('edittitle').value;
		this.const_apikey = document.getElementById('editapikey').value;
        this.const_token = document.getElementById('editaccesstkn').value;
        this.const_listid = document.getElementById('editlistid').value;
		this.constantcont=true;
		}
		else if(this.autoname == "getresponse"){
		this.autoid = document.getElementById('autoid').value;
		this.get_title = document.getElementById('edittitle').value;
		this.get_apikey = document.getElementById('editapikey').value;
        this.get_campaignid = document.getElementById('editcampid').value;
			this.getresponse=true;
		}
		else if(this.autoname == "hubspot"){
		this.autoid = document.getElementById('autoid').value;
		this.hub_title = document.getElementById('edittitle').value;
		 this.hub_apikey = document.getElementById('editapikey').value;
			this.hubspot=true;
		}
		else if(this.autoname == "mailchimp"){
		this.autoid = document.getElementById('autoid').value;
		this.mail_title = document.getElementById('edittitle').value;
		this.mail_apikey = document.getElementById('editapikey').value;
        this.mail_listid = document.getElementById('editlistid').value;
			this.mailchimp=true;
		}
		else if(this.autoname == "ontraport"){
		this.autoid = document.getElementById('autoid').value;
		this.ontra_title = document.getElementById('edittitle').value;
		this.ontra_apikey = document.getElementById('editapikey').value;
        this.ontra_appid = document.getElementById('editappid').value;
			this.ontraport=true;
		}
		else if(this.autoname == "aweber"){
		this.autoid = document.getElementById('autoid').value;
		this.cus_title = document.getElementById('edittitle').value;
		this.cus_key = document.getElementById('editapikey').value;
        this.cus_secret = document.getElementById('editaccesstkn').value;
        this.acc_id = document.getElementById('editappid').value;
        this.list_id = document.getElementById('editlistid').value;
			this.aweber=true;
		}
	}
	try{
		doEscapePopup(function(){thisvue.closeForm(thisvue.autoname);});
	}catch(err){}
	},
	closeForm:function(type){
		this.err="";
		if (type == "mailengine") {
			this.mailengine=false;
		}
		if (type == "activecampaign") {
			this.activecampaign=false;
		}
		else if(type == "constantcont"){
			this.constantcont=false;
		}
		else if(type == "getresponse"){
			this.getresponse=false;
		}
		else if(type == "hubspot"){
			this.hubspot=false;
		}
		else if(type == "mailchimp"){
			this.mailchimp=false;
		}
		else if(type == "ontraport"){
			this.ontraport=false;
		}
		else if (type == "aweber") {
			this.aweber=false;
		}
	},
	showForm:function(autotype){
		// this.mainblock=true;
		var thisvue=this;
		this.err="";
		if (autotype == "mailengine") {
			this.mailengine=true;
			this.activecampaign=false;
			this.constantcont=false;
			this.getresponse=false;
			this.hubspot=false;
			this.mailchimp=false;
			this.ontraport=false;
			this.aweber=false;
		}
		if (autotype == "activecampaign") {
			this.activecampaign=true;
			this.constantcont=false;
			this.getresponse=false;
			this.hubspot=false;
			this.mailchimp=false;
			this.ontraport=false;
			this.aweber=false;
		}
		else if(autotype == "constantcont"){
			this.constantcont=true;
			this.activecampaign=false;
			this.getresponse=false;
			this.hubspot=false;
			this.mailchimp=false;
			this.ontraport=false;
			this.aweber=false;
		}
		else if(autotype == "getresponse"){
			this.getresponse=true;
			this.activecampaign=false;
			this.constantcont=false;
			this.hubspot=false;
			this.mailchimp=false;
			this.ontraport=false;
			this.aweber=false;
		}
		else if(autotype == "hubspot"){
			this.hubspot=true;
			this.activecampaign=false;
			this.getresponse=false;
			this.getresponse=false;
			this.mailchimp=false;
			this.ontraport=false;
			this.aweber=false;
		}
		else if(autotype == "mailchimp"){
			this.mailchimp=true;
			this.constantcont=false;
			this.activecampaign=false;
			this.getresponse=false;
			this.hubspot=false;
			this.ontraport=false;
			this.aweber=false;
		}
		else if(autotype == "ontraport"){
			this.ontraport=true;
			this.constantcont=false;
			this.activecampaign=false;
			this.getresponse=false;
			this.hubspot=false;
			this.mailchimp=false;
			this.aweber=false;
		}
		else if(autotype == "aweber"){
			this.aweber=true;
			this.constantcont=false;
			this.activecampaign=false;
			this.getresponse=false;
			this.hubspot=false;
			this.mailchimp=false;
			this.ontraport=false;
		}
		try{doEscapePopup(function(){thisvue.closeForm(autotype);});}catch(err){}
	},
	saveMailEngine:function(e){
		if (this.mailengine_title.length>0 && this.mailengine_apiurl.length>0 && this.mailengine_apikey.length>0) {
		var thisvue = this;
		this.err="";
		var data={"mailengine":1,"autotype":"mailengine","apikey":this.mailengine_apikey,"apiurl":this.mailengine_apiurl,"listid":this.mailengine_listid,"appid":"null","campid":"null","accesstoken":"null","email":this.mailengine_email,"title":this.mailengine_title,"autoid":this.autoid};
		// alert(data);
		e.target.disabled=true;
		request.postRequestCb('req.php',data,function(result){
			e.target.disabled=false;
			if(result.trim()=='1')
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: rgb(72, 161, 79);'>API Details Saved Successfully</center></p>";
				// alert(err);
				}
			    else
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Failed To Save API Credentials. Please use correct API Credentials.</center></p>";	
				// alert(err);
				// alert("Status:"+result.trim());
				}
		});
		}
		else{
			this.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Please Fill All Details.</center></p>";
		}
	},
	saveactivecampaign:function(e){
		if (this.active_title.length>0 && this.active_apiurl.length>0 && this.active_apikey.length>0) {
		var thisvue = this;
		this.err="";
		var data={"activecampaignn":1,"autotype":"activecampaign","apikey":this.active_apikey,"apiurl":this.active_apiurl,"listid":this.active_listid,"appid":"null","campid":"null","accesstoken":"null","email":"null","title":this.active_title,"autoid":this.autoid};
		// alert(data);
		e.target.disabled=true;
		request.postRequestCb('req.php',data,function(result){
			e.target.disabled=false;
			if(result.trim()=='1')
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: rgb(72, 161, 79);'>API Details Saved Successfully</center></p>";
				// alert(err);
				}
			    else
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Failed To Save API Credentials. Please use correct API Credentials.</center></p>";	
				// alert(err);
				// alert("Status:"+result.trim());
				}
		});
		}
		else{
			this.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Please Fill All Details.</center></p>";
		}
	},
	savemailchimp:function(e){
		// this.mainblock=false;
		// this.mailchimp=true;
		if (this.mail_apikey.length>0 && this.mail_listid.length>0 && this.mail_title.length>0) {
		var thisvue = this;
		this.err="";
		var data={"mailchimp":1,"autotype":"mailchimp","apikey":this.mail_apikey,"listid":this.mail_listid,"apiurl":"null","appid":"null","accesstoken":"null","campid":"null","email":this.mail_email,"title":this.mail_title,"autoid":this.autoid};
		// alert(data);
		e.target.disabled=true;
		request.postRequestCb('req.php',data,function(result){
			e.target.disabled=false;
				if(result.trim()=='1')
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: rgb(72, 161, 79);'>API Details Saved Successfully</center></p>";
				// alert(err);
				}
			    else
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Failed To Save API Credentials. Please use correct API Credentials.</center></p>";	
				// alert(err);
				// alert("Status:"+result.trim());
				}
		});
		}
		else{
			this.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Please Fill All Details.</center></p>";
		}
	},
	savegetresponse:function(e){
		// this.mainblock=false;
		// this.getresponse=true;
		if (this.get_apikey.length>0 && this.get_campaignid.length>0 && this.get_title.length>0) {
		var thisvue = this;
		this.err="";
		var data={"getresponse":1,"autotype":"getresponse","apikey":this.get_apikey,"listid":"null","apiurl":"null","accesstoken":"null","appid":"null","campid":this.get_campaignid,"email":this.get_email,"title":this.get_title,"autoid":this.autoid};
		// alert(data);
		e.target.disabled=true;
		request.postRequestCb('req.php',data,function(result){
			e.target.disabled=false;
				if(result.trim()=='1')
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: rgb(72, 161, 79);'>API Details Saved Successfully</center></p>";
				// alert(err);
				}
			    else
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Failed To Save API Credentials. Please use correct API Credentials.</center></p>";	
				// alert(err);
				// alert("Status:"+result.trim());
				}
		});
		}
		else{
			this.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Please Fill All Details.</center></p>";
		}
	},
	saveconstantcont:function(e){
		// this.mainblock=false;
		// this.constantcont=true;
		if (this.const_apikey.length>0 && this.const_token.length>0 && this.const_listid.length>0 && this.const_email.length>0 && this.const_title.length>0) {
		var thisvue = this;
		this.err="";
		var data={"constantcont":1,"autotype":"constantcont","apikey":this.const_apikey,"listid":this.const_listid,"apiurl":"null","appid":"null","campid":"null","accesstoken":this.const_token,"email":this.const_email,"title":this.const_title,"autoid":this.autoid};
		// alert(data);
		e.target.disabled=true;
		request.postRequestCb('req.php',data,function(result){
			e.target.disabled=false;
				if(result.trim()=='1')
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: rgb(72, 161, 79);'>API Details Saved Successfully</center></p>";
				// alert(err);
				}
			    else
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Failed To Save API Credentials. Please use correct API Credentials.</center></p>";	
				// alert(err);
				// alert("Status:"+result.trim());
				}
		});
		}
		else{
			this.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Please Fill All Details.</center></p>";
		}
	},
	saveontraport:function(e)
	{
		// this.mainblock=false;
		// this.ontraport=true;
		if (this.ontra_apikey.length>0 && this.ontra_appid.length>0 && this.ontra_title.length>0) {
		var thisvue = this;
		this.err="";
		var data={"ontraport":1,"autotype":"ontraport","apikey":this.ontra_apikey,"listid":"null","apiurl":"null","campid":"null","accesstoken":"null","appid":this.ontra_appid,"email":this.ontra_email,"title":this.ontra_title,"autoid":this.autoid};
		// alert(data);
		e.target.disabled=true;
		request.postRequestCb('req.php',data,function(result){
			e.target.disabled=false;
				if(result.trim()=='1')
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: rgb(72, 161, 79);'>API Details Saved Successfully</center></p>";
				// alert(err);
				}
			    else
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Failed To Save API Credentials. Please use correct API Credentials.</center></p>";	
				// alert(err);
				// alert("Status:"+result.trim());
				}
		});
		}
		else{
			this.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Please Fill All Details.</center></p>";
		}
	},
	savehubspot:function(e)
	{
		// this.mainblock=false;
		// this.hubspot=true;
		if (this.hub_apikey.length>0 && this.hub_title.length>0 && this.hub_email.length>0) {
		var thisvue = this;
		this.err="";
		var data={"hubspot":1,"autotype":"hubspot","apikey":this.hub_apikey,"listid":"null","apiurl":"null","campid":"null","accesstoken":"null","appid":"null","email":this.hub_email,"title":this.hub_title,"autoid":this.autoid};
		// alert(data);
		e.target.disabled=true;
		request.postRequestCb('req.php',data,function(result){
			e.target.disabled=false;
				if(result.trim()=='1')
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: rgb(72, 161, 79);'>API Details Saved Successfully</center></p>";
				// alert(err);
				}
			    else
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Failed To Save API Credentials. Please use correct API Credentials.</center></p>";	
				// alert(err);
				// alert("Status:"+result.trim());
				}
		});
		}
		else{
			this.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Please Fill All Details.</center></p>";
		}	
	},
	saveaweber:function(e){
		if (this.cus_key.length>0 && this.cus_secret.length>0 && this.cus_email.length>0 && this.acc_id.length>0 && this.list_id.length>0 && this.cus_title.length>0) {
		var thisvue = this;	
		this.err="";
		var data={"aweber":1,"autotype":"aweber","apikey":this.cus_key,"listid":this.list_id,"apiurl":"null","campid":"null","accesstoken":this.cus_secret,"appid":this.acc_id,"email":this.cus_email,"title":this.cus_title,"autoid":this.autoid};
		// alert(data);
		e.target.disabled=true;
		request.postRequestCb('req.php',data,function(result){
			e.target.disabled=false;
				if(result.trim()=='1')
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: rgb(72, 161, 79);'>API Details Saved Successfully</center></p>";
				// alert(err);
				}
			    else
				{
				thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Failed To Save API Credentials. Please use correct API Credentials.</center></p>";	
				// alert(err);
				// alert("Status:"+result.trim());
				}
		});
		}
		else{
			this.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Please Fill All Details.</center></p>";
		}
	},

		}
});


