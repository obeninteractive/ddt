<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once('aweber_api/aweber_api.php');
$consumerKey = '**********';
$consumerSecret = '**********';
$accessKey      = '***'; # put your credentials here
$accessSecret   = '***'; # put your credentials here
$account_id     = '***'; # put the Account ID here
$list_id        = 'awlist5252553'; # put the List ID here
$aweber = new AWeberAPI($consumerKey, $consumerSecret);
# Get an access token
if (empty($_COOKIE['accessToken']))
    {
        if (empty($_GET['oauth_token'])) 
            {
                $callbackUrl = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
                list($requestToken, $requestTokenSecret) = $aweber->getRequestToken($callbackUrl);
                setcookie('requestTokenSecret', $requestTokenSecret);
                setcookie('callbackUrl', $callbackUrl);
                header("Location: {$aweber->getAuthorizeUrl()}");
                exit();
            }
        $aweber->user->tokenSecret = $_COOKIE['requestTokenSecret'];
        $aweber->user->requestToken = $_GET['oauth_token'];
        $aweber->user->verifier = $_GET['oauth_verifier'];
        list($accessToken, $accessTokenSecret) = $aweber->getAccessToken();
        setcookie('accessToken', $accessToken);
        setcookie('accessTokenSecret', $accessTokenSecret);
        header('Location: '.$_COOKIE['callbackUrl']);
        exit();
}
# Get AWeber Account
try {
        $account = $aweber->getAccount($_COOKIE['accessToken'], $_COOKIE['accessTokenSecret']);
        $listURL = "/accounts/".$account_id."/lists/".$list_id;
        $list = $account->loadFromUrl($listURL);
        # create a subscriber
        $params = array(
            'email' => $_POST['email']
        );
        $subscribers = $list->subscribers;
        $new_subscriber = $subscribers->create($params);
        # success!
        print "A new subscriber was added to the $list->name list!";

    }
catch(AWeberAPIException $exc) 
    {
        print "<h3>AWeberAPIException:</h3>";
        print " <li> Type: $exc->type              <br>";
        print " <li> Msg : $exc->message           <br>";
        print " <li> Docs: $exc->documentation_url <br>";
        print "<hr>";
        exit(1);
    }
 ?>